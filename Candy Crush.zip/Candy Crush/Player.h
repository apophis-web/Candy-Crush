#ifndef PLAYER_H_
#define PLAYER_H_
#include <iostream>
using namespace std;

class Player
{
protected:
	string name1;
	int score;
	int diffi;
	int TIME;
public:
	struct highScore
	{
		int Time;
		string Name;
	};
	highScore X[100];
	Player();
	Player(string name1, int score);
	void setScore(int score);
	void incrementScore();
	int getScore();
	void setDifficulty(int diffi);
	int getDifficulty();
	void appName(char letter);
	string getName();
	void setTime(int TIME);
	int getTime();
	void writeData();
	~Player();
};
#endif