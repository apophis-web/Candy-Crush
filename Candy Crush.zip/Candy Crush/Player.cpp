#include "Player.h"
#include <fstream>

Player::Player()
{
	TIME = 0;
	score = 0;
	diffi = 1;   //Difficulty is easy by default
}
Player::Player(string name1, int score)
{
	this->name1 = name1;
	this->score = score;
	this->diffi = diffi;
}
void Player::setScore(int score)
{
	this->score = score;
}
void Player::incrementScore()
{
	score++;
}
int Player::getScore()
{
	return score;
}
void Player::setDifficulty(int diffi)
{
	this->diffi = diffi;
}
int Player::getDifficulty()
{
	return diffi;
}
void Player::appName(char letter)
{
	name1 += letter;
}
string Player::getName()
{
	return name1;
}
void Player::setTime(int TIME)
{
	this->TIME = TIME;
}
int Player::getTime()
{
	return TIME;
}
void Player::writeData()
{
	for (int i = 0; i < 100; i++)
	{
		X[i].Time = 0;
		X[i].Name = "";
	}
	fstream highscore;

	highscore.open("highscore.txt", ios::app);
	highscore << getTime() << " " << getName() << endl;
	highscore.close();

	highscore.open("highscore.txt", ios::in);
	int k = 0;
	while (!highscore.eof())
	{
		highscore >> X[k].Time;
		highscore >> X[k].Name;
		k++;
	}
	highscore.close();
	for (int i = 0; i < k; i++)
	{
		for (int j = i + 1; j < k; j++)
		{
			if (X[i].Time > X[j].Time)
			{
				swap(X[i], X[j]);
			}
		}
	}
	X[0].Time = 0;
	X[0].Name = "NoName";

	fstream saves;
	saves.open("saves.txt", ios::out);
	for (int i = 0; i < k; i++)
	{
		saves << X[i].Time << " " << X[i].Name << endl;
	}
	saves.close();
}
Player::~Player(){};