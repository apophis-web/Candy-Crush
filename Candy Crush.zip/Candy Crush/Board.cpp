#include "Board.h"
#include "util.h"
#include <iostream>
#include <string>
#include <cmath>
#include <stdlib.h>
#include <ctime>

void Board::Make()
{
	srand(time(NULL));
	int r;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			grid[j][i].setX(i);
			grid[j][i].setY(j);
			r = rand() % 5;
			if (r == 0)
				grid[j][i].setColor('W');
			if (r == 1)
				grid[j][i].setColor('R');
			if (r == 2)
				grid[j][i].setColor('Y');
			if (r == 3)
				grid[j][i].setColor('G');
			if (r == 4)
				grid[j][i].setColor('O');
		}
	}
}
Board::Board()
{
	menu = false;
	cond1 = false;
	cond2 = false;
	cond3 = false;
	pause = false;
	highscoreMenu = false;
	grid = new Gems * [size];
	for (int i = 0; i < size; i++)
	{
		grid[i] = new Gems[size];
	}
	Make();
}
void Board::Check()
{
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			if (j < size - 2)
			{
				if (grid[i][j].getColor() == grid[i][j + 1].getColor() && grid[i][j + 1].getColor() == grid[i][j + 2].getColor())
				{
					if (j < size - 3)
					{
						if (j < size - 4)
						{
							if (grid[i][j + 3].getColor() == grid[i][j + 4].getColor())
								grid[i][j + 4].setColor('*');
						}
						if (grid[i][j + 2].getColor() == grid[i][j + 3].getColor())
							grid[i][j + 3].setColor('*');
					}
					grid[i][j].setColor('*');
					grid[i][j + 1].setColor('*');
					grid[i][j + 2].setColor('*');
				}
			}

			if (j >= size - 6)
			{
				if (grid[i][j].getColor() == grid[i][j - 1].getColor() && grid[i][j - 1].getColor() == grid[i][j - 2].getColor())
				{
					if (j >= size - 5)
					{
						if (j >= size - 4)
						{
							if (grid[i][j - 3].getColor() == grid[i][j - 4].getColor())
								grid[i][j - 4].setColor('*');
						}
						if (grid[i][j - 2].getColor() == grid[i][j - 3].getColor())
							grid[i][j - 3].setColor('*');
					}
					grid[i][j].setColor('*');
					grid[i][j - 1].setColor('*');
					grid[i][j - 2].setColor('*');
				}
			}

			if (i < size - 2)
			{
				if (grid[i][j].getColor() == grid[i + 1][j].getColor() && grid[i + 1][j].getColor() == grid[i + 2][j].getColor())
				{
					if (i < size - 3)
					{
						if (i < size - 4)
						{
							if (grid[i + 3][j].getColor() == grid[i + 4][j].getColor())
								grid[i + 4][j].setColor('*');
						}
						if (grid[i + 2][j].getColor() == grid[i + 3][j].getColor())
							grid[i + 3][j].setColor('*');
					}
					grid[i][j].setColor('*');
					grid[i + 1][j].setColor('*');
					grid[i + 2][j].setColor('*');
				}
			}

			if (i >= size - 6)
			{
				if (grid[i][j].getColor() == grid[i - 1][j].getColor() && grid[i - 1][j].getColor() == grid[i - 2][j].getColor())
				{
					if (i >= size - 5)
					{
						if (i >= size - 4)
						{
							if (grid[i - 3][j].getColor() == grid[i - 4][j].getColor())
								grid[i - 4][j].setColor('*');
						}
						if (grid[i - 2][j].getColor() == grid[i - 3][j].getColor())
							grid[i - 3][j].setColor('*');
					}
					grid[i][j].setColor('*');
					grid[i - 1][j].setColor('*');
					grid[i - 2][j].setColor('*');
				}
			}
		}
	}
}
void Board::Delete()
{
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			if (grid[i][j].getColor() == '*')
			{
				grid[i][j].setColor('\0');
			}
		}
	}
}
void Board::Drop()
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (grid[i][j].getColor() == '\0')
			{
				for (int k = 0; k < 8; k++)
				{
					if (i - k > 0)
					{
						grid[i - k][j].setColor(grid[(i - k) - 1][j].getColor());
					}
					else
					{
						int r;
						r = rand() % 5;
						if (r == 0)
							grid[0][j].setColor('W');
						if (r == 1)
							grid[0][j].setColor('R');
						if (r == 2)
							grid[0][j].setColor('Y');
						if (r == 3)
							grid[0][j].setColor('G');
						if (r == 4)
							grid[0][j].setColor('O');
						break;
					}
				}
			}

		}
	}
}
void Board::Swap(int x1, int y1, int x2, int y2)
{
	static int p1 = 0;
	static int p2 = 0;
	static int p3 = 0;
	static int p4 = 0;
	static int p5 = 0;
	static int p6 = 0;

	char save1, save2;
	save1 = grid[y1][x1].getColor();

	if (x2 <= 6)
	{
		if (save1 == grid[y2][x2 + 1].getColor())
		{
			p1++;
			p5++;
		}
	}
	if (x2 <= 5)
	{
		if (save1 == grid[y2][x2 + 2].getColor())
			p1++;
	}
	if (x2 >= 1)
	{
		if (save1 == grid[y2][x2 - 1].getColor())
		{
			p2++;
			p5++;
		}
	}
	if (x2 >= 2)
	{
		if (save1 == grid[y2][x2 - 2].getColor())
			p2++;
	}



	if (y2 <= 6)
	{
		if (save1 == grid[y2 + 1][x2].getColor())
		{
			p3++;
			p6++;
		}
	}
	if (y2 <= 5)
	{
		if (save1 == grid[y2 + 2][x2].getColor())
			p3++;
	}
	if (y2 >= 1)
	{
		if (save1 == grid[y2 - 1][x2].getColor())
		{
			p4++;
			p6++;
		}
	}
	if (y2 >= 2)
	{
		if (save1 == grid[y2 - 2][x2].getColor())
			p4++;
	}

	if (p1 == 2 || p2 == 2 || p3 == 2 || p4 == 2 || p5 == 2 || p6 == 2)
	{
		incrementScore();
		save2 = grid[y2][x2].getColor();
		grid[y1][x1].setColor(save2);
		grid[y2][x2].setColor(save1);
		cout << "\nSwap Called" << endl;
	}

	p1 = 0;
	p2 = 0;
	p3 = 0;
	p4 = 0;
	p5 = 0;
	p6 = 0;
}
void Board::setPause(bool cond)
{
	pause = cond;
}
bool Board::getPause()
{
	return pause;
}
void Board::setMenu(bool cond)
{
	menu = cond;
}
bool Board::getMenu()
{
	return menu;
}
void Board::setCond1(bool cond)
{
	cond1 = cond;
}
bool Board::getCond1()
{
	return cond1;
}
void Board::setCond2(bool cond)
{
	cond2 = cond;
}
bool Board::getCond2()
{
	return cond2;
}
void Board::setCond3(bool cond)
{
	cond3 = cond;
}
bool Board::getCond3()
{
	return cond3;
}
void Board::setHighScoreMenu(bool highscoreMenu)
{
	this->highscoreMenu = highscoreMenu;
}
bool Board::getHighScoreMenu()
{
	return highscoreMenu;
}
void Board::Display()
{
	if (menu == false && cond1 == false && highscoreMenu == false)
	{
		DrawString(420, 850, "CANDY CRUSH", colors[MISTY_ROSE]);
		DrawString(100, 700, "1. Play", colors[MISTY_ROSE]);
		DrawString(100, 650, "2. Increase Difficulty", colors[MISTY_ROSE]);
		DrawString(100, 600, "3. Exit", colors[MISTY_ROSE]);
		DrawString(100, 550, "4. High Score", colors[MISTY_ROSE]);
		DrawString(600, 100, "[Use right click to navigate the menu]", colors[MISTY_ROSE]);
	}
	if (menu == false && cond1 == true && highscoreMenu == false)
	{
		DrawString(420, 850, "CANDY CRUSH", colors[MISTY_ROSE]);
		DrawString(70, 200, "Increase The Difficulty Level:", colors[MISTY_ROSE]);
		DrawString(70, 160, "~Medium  (Get 20 score in 45 seconds to win)", colors[MISTY_ROSE]);
		DrawString(70, 120, "~Hard    (Get 20 score in 30 seconds to win)", colors[MISTY_ROSE]);
	}
	if (menu == false && cond1 == false && highscoreMenu == true)
	{
		DrawString(420, 850, "CANDY CRUSH", colors[MISTY_ROSE]);
		DrawString(420, 800, "HIGH SCORES", colors[MISTY_ROSE]);
		DrawString(400, 700, "Time", colors[MISTY_ROSE]);
		DrawString(500, 700, "Name", colors[MISTY_ROSE]);
		DrawString(400, 650, Num2Str(X[1].Time), colors[MISTY_ROSE]);
		DrawString(400, 600, Num2Str(X[2].Time), colors[MISTY_ROSE]);
		DrawString(400, 550, Num2Str(X[3].Time), colors[MISTY_ROSE]);
		DrawString(500, 650, X[1].Name, colors[MISTY_ROSE]);
		DrawString(500, 600, X[2].Name, colors[MISTY_ROSE]);
		DrawString(500, 550, X[3].Name, colors[MISTY_ROSE]);
	}
	if (menu == true && cond3 == false)
	{
		//DrawString(100, 700, "What is your name?", colors[MISTY_ROSE]);
		setCond3(true);
	}
	if (menu == true && cond3 == true)
	{
		for (int i = 0; i < 5; i++)
		{
			Check();
			Delete();
			Drop();
		}
		DrawString(50, 800, "Score = " + Num2Str(score), colors[WHITE]);
		if (getDifficulty() == 1)
			DrawString(50, 850, "Difficulty: Easy", colors[WHITE]);
		if (getDifficulty() == 2)
			DrawString(50, 850, "Difficulty: Medium", colors[WHITE]);
		if (getDifficulty() == 3)
			DrawString(50, 850, "Difficulty: Hard", colors[WHITE]);
		DrawString(730, 500, "Press 'H' for a hint", colors[WHITE]);
		DrawRoundRect(940, 490, 35, 40, colors[MEDIUM_PURPLE], 35);
		static int x2 = 300;
		//(x1,y1,x2,y2,thickness)
		DrawLine(300, 240, x2 + ((score) * 20), 240, 20, colors[BLUE]);
		DrawLine(290, 260, 690, 260, 5, colors[WHITE]);
		DrawLine(290, 220, 690, 220, 5, colors[WHITE]);
		DrawLine(290, 220, 290, 260, 5, colors[WHITE]);
		DrawLine(690, 220, 690, 260, 5, colors[WHITE]);
		DrawString(90, 590, "Pause", colors[WHITE]);
		DrawCircle(200, 600, 30, colors[TEAL]);

		if (getPause() == false)
			DrawString(193, 593, "|>", colors[WHITE]);

		if (getPause() == true)
			DrawString(193, 593, "||", colors[WHITE]);

		int k = 650;
		for (int i = 0; i < 8; i++)
		{
			int x = 250;
			for (int j = 0; j < 8; j++)
			{
				x = x + 50;
				if (grid[i][j].getColor() == 'W')
				{
					DrawTriangle(x, k, x + 40, k, x + 20, k + 40, colors[WHITE]);
				}

				if (grid[i][j].getColor() == 'R')
				{
					DrawCircle(x + 20, k + 20, 20, colors[RED]);
				}

				if (grid[i][j].getColor() == 'Y')
				{
					DrawRoundRect(x, k, 35, 40, colors[YELLOW], 30);
				}

				if (grid[i][j].getColor() == 'G')
				{
					DrawTriangle(x, k, x + 40, k, x + 20, k + 40, colors[DARK_GREEN]);
				}

				if (grid[i][j].getColor() == 'O')
				{
					DrawSquare(x, k, 40, colors[DARK_ORANGE]);
				}

				if (grid[i][j].getColor() == 'P')
				{
					DrawRoundRect(x, k, 35, 40, colors[MEDIUM_PURPLE], 35);
				}
			}
			k = k - 50;
		}
	}
}
void Board::Hint()
{
	bool condition = false;
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (condition == true)
			{
				break;
			}
			if (grid[i][j].getColor() == grid[i][j + 1].getColor() && (j <= 6))
			{
				if (grid[i][j].getColor() == grid[i][j - 2].getColor() && (j >= 2))
				{
					condition = true;
					grid[i][j].setColor('P');
					grid[i][j + 1].setColor('P');
					grid[i][j - 2].setColor('P');
				}
				else if (grid[i][j].getColor() == grid[i][j + 3].getColor() && (j <= 4))
				{
					condition = true;
					grid[i][j].setColor('P');
					grid[i][j + 1].setColor('P');
					grid[i][j + 3].setColor('P');
				}
				else if (i > 0 && i < 8)
				{
					if (grid[i][j].getColor() == grid[i - 1][j - 1].getColor() && (j > 0))
					{
						condition = true;
						grid[i][j].setColor('P');
						grid[i][j + 1].setColor('P');
						grid[i - 1][j - 1].setColor('P');
					}
				}
				else if (i >= 0 && i <= 6)
				{
					if (grid[i][j].getColor() == grid[i + 1][j + 2].getColor() && (j <= 5))
					{
						condition = true;
						grid[i][j].setColor('P');
						grid[i][j + 1].setColor('P');
						grid[i + 1][j + 2].setColor('P');
					}
				}
			}
			if (condition == false)
			{
				if (i <= 6)
				{
					if (grid[i][j].getColor() == grid[i + 1][j].getColor())
					{
						if (i >= 2)
						{
							if (grid[i][j].getColor() == grid[i - 2][j].getColor())
							{
								condition = true;
								grid[i][j].setColor('P');
								grid[i + 1][j].setColor('P');
								grid[i - 2][j].setColor('P');
							}
						}
						else if (i <= 4)
						{
							if (grid[i][j].getColor() == grid[i + 3][j].getColor())
							{
								condition = true;
								grid[i][j].setColor('P');
								grid[i + 1][j].setColor('P');
								grid[i + 3][j].setColor('P');
							}
						}
					}
				}
			}
		}
		if (condition == true)
		{
			break;
		}
	}
}
Board::~Board() {};