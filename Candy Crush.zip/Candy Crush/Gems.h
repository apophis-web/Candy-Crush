#ifndef GEMS_H_
#define GEMS_H_
class Gems
{
protected:
	int x1, y1;
	int x, y;
	char color;
public:
	Gems();
	Gems(int x, int y, int x1, int y1, char color);
	void setX(int x);
	void setY(int y);
	void setX1(int x1);
	void setY1(int y1);
	void setColor(char color);
	int getX();
	int getY();
	int getX1();
	int getY1();
	char getColor();
	~Gems();
};
#endif