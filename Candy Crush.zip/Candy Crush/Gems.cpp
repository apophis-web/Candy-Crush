#include "Gems.h"

Gems::Gems()
{	
	x1 = 0;
	y1 = 0;
	x = 0;
	y = 0;
	color = '\0';
}
Gems::Gems(int x, int y, int x1, int y1, char color)
{
	this->x = x;
	this->y = y;
	this->x1 = x1;
	this->y1 = y1;
	this->color = color;
}
void Gems::setX(int x)
{
	this->x = x;
}
void Gems::setY(int y)
{
	this->y = y;
}
void Gems::setX1(int x1)
{
	this->x1 = x1;
}
void Gems::setY1(int y1)
{
	this->y1 = y1;
}
void Gems::setColor(char color)
{
	this->color = color;
}
int Gems::getX()
{
	return x;
}
int Gems::getY()
{
	return y;
}
int Gems::getX1()
{
	return x1;
}
int Gems::getY1()
{
	return y1;
}
char Gems::getColor()
{
	return color;
}
Gems::~Gems() {};