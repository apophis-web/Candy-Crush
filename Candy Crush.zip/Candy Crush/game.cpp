#include "util.h"
#include "Gems.h"
#include "Player.h"
#include "Board.h"
#include <iostream>
#include <string>
#include <cmath>
#include <stdlib.h>
#include <ctime>
#include <chrono>
#include <fstream>
using namespace std;

Board A;
void NonPrintableKeys(int key, int x, int y)
{
	if (key
		== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...

	}
	else if (key
		== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {

	}
	else if (key
		== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {

	}

	else if (key
		== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {

	}
	glutPostRedisplay();
}
void PrintableKeys(unsigned char key, int x, int y)
{
	if (key == 27/* Escape key ASCII*/)
	{
		exit(1);
	}
	if (key == 13/* Enter key ASCII*/)
	{
		A.writeData();
		exit(1);
	}
	if (A.getMenu() == true && A.getCond3() == true)
	{
		if (key == 'h' || key == 'H')
		{
			A.Hint();
		}
	}
	if (A.getScore() >= 20)
	{
		A.appName(key);
	}
	glutPostRedisplay();
}
void Timer(int m)
{
	//Once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(100.0, Timer, 0);
	glutPostRedisplay();
}
void GameDisplay()
{
	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
		0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear(GL_COLOR_BUFFER_BIT);
	if (A.getMenu() == true)
	{
		static int time = 0;
		static int endTime = 0;
		if (A.getCond2() == false)
		{
			DrawString(50, 750, "Timer: " + Num2Str(time / 9), colors[WHITE]);
			if (A.getPause() == false)
				time++;
		}
		if (A.getDifficulty() == 1)
		{
			if (time >= (60 * 9) + 9)
			{
				DrawString(450, 450, "You Lost!", colors[WHITE]);
				DrawString(400, 350, "Your score was " + Num2Str(A.getScore()), colors[WHITE]);
				A.setCond2(true);
			}
			if (A.getScore() >= 20)
			{
				endTime = time;
				A.setTime(endTime / 9);
				DrawString(450, 450, "You Won!", colors[WHITE]);
				DrawString(400, 350, "What is your name?", colors[MISTY_ROSE]);
				DrawString(400, 300, A.getName(), colors[MISTY_ROSE]);
				A.setCond2(true);
			}
		}
		if (A.getDifficulty() == 2)
		{
			if (time >= (45 * 9) + 9)
			{
				DrawString(450, 450, "You Lost!", colors[WHITE]);
				DrawString(400, 350, "Your score was " + Num2Str(A.getScore()), colors[WHITE]);
				A.setCond2(true);
			}
			if (A.getScore() >= 20)
			{
				endTime = time;
				A.setTime(endTime / 9);
				DrawString(450, 450, "You Won!", colors[WHITE]);
				DrawString(400, 350, "What is your name?", colors[MISTY_ROSE]);
				DrawString(400, 300, A.getName(), colors[MISTY_ROSE]);
				A.setCond2(true);
			}
		}
		if (A.getDifficulty() == 3)
		{
			if (time >= (30 * 9) + 9)
			{
				DrawString(450, 450, "You Lost!", colors[WHITE]);
				DrawString(400, 350, "Your score was " + Num2Str(A.getScore()), colors[WHITE]);
				A.setCond2(true);
			}
			if (A.getScore() >= 20)
			{
				endTime = time;
				A.setTime(endTime / 9);
				DrawString(450, 450, "You Won!", colors[WHITE]);
				DrawString(400, 350, "What is your name?", colors[MISTY_ROSE]);
				DrawString(400, 300, A.getName(), colors[MISTY_ROSE]);
				A.setCond2(true);
			}
		}
	}
	if (A.getCond2() == false)
		A.Display();
	glutSwapBuffers();
}
void SetCanvasSize(int width, int height)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
void MouseClicked(int button, int state, int x, int y)
{
	static int P = 0;
	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == 0)
		{
			if ((x >= 170 && x <= 230) && (y >= 375 && y <= 425))
			{
				if (P % 2 == 0)
				{
					A.setPause(true);
				}
				if (P % 2 == 1)
				{
					A.setPause(false);
				}
				P++;
			}
			A.setX((x / 50) - 6);
			A.setY((y / 50) - 6);
			cout << "Button Pressed" << endl;
			cout << (x / 50) - 6 << " " << (y / 50) - 6 << endl;
		}
		if (state == 1)
		{
			A.setX1((x / 50) - 6);
			A.setY1((y / 50) - 6);
			cout << "Button Released" << endl;
			cout << (x / 50) - 6 << " " << (y / 50) - 6 << endl;
			if ((A.getX() == A.getX1()) || (A.getY() == A.getY1()))
			{
				if ((A.getX() - A.getX1() == 1) || (A.getX() - A.getX1() == -1) || (A.getY() - A.getY1() == 1) || (A.getY() - A.getY1() == -1))
				{
					if (A.getPause() == false)
					{
						A.Swap(A.getX(), A.getY(), A.getX1(), A.getY1());
					}
				}
			}
			cout << "Score is " << A.getScore() << endl;
		}
	}
	else if (button == GLUT_RIGHT_BUTTON)
	{
		if ((x >= 130 && x <= 165) && (y >= 280 && y <= 300))
		{
			A.setMenu(true);
		}
		if ((x >= 130 && x <= 175) && (y >= 335 && y <= 350))
		{
			A.setCond1(true);
		}
		if ((x >= 85 && x <= 165) && (y >= 825 && y <= 840))
		{
			A.setDifficulty(2);
			A.setMenu(true);
		}
		if ((x >= 85 && x <= 165) && (y >= 865 && y <= 880))
		{
			A.setDifficulty(3);
			A.setMenu(true);
		}
		if ((x >= 130 && x <= 165) && (y >= 385 && y <= 400))
		{
			exit(1);
		}
		if ((x >= 130 && x <= 235) && (y >= 435 && y <= 455))
		{
			//HighScore
			fstream file;
			file.open("saves.txt", ios::in);
			static int k = 0;
			while (!file.eof())
			{
				file >> A.X[k].Time;
				file >> A.X[k].Name;
				k++;
			}
			file.close();
			A.setHighScoreMenu(true);
		}
		cout << x << " " << y;
		cout << " Right Button Pressed" << endl;
	}
	glutPostRedisplay();
}
int main(int argc, char* argv[])
{
	int width = 1000, height = 1000;

	InitRandomizer();

	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);

	glutInitWindowPosition(50, 50);

	glutInitWindowSize(width, height);

	glutCreateWindow("C A N D Y    C R U S H");

	SetCanvasSize(width, height);

	glutMouseFunc(MouseClicked);

	glutDisplayFunc(GameDisplay);

	glutSpecialFunc(NonPrintableKeys);

	glutKeyboardFunc(PrintableKeys);

	glutTimerFunc(100.0, Timer, 0);

	glutMainLoop();

	return 1;
}