#ifndef BOARD_H_
#define BOARD_H_
#include "Player.h"
#include "Gems.h"
class Board :public Gems, public Player
{
private:
	bool menu;
	bool cond1;
	bool cond2;
	bool cond3;
	bool pause;
	bool highscoreMenu;
	int size = 8;
	Gems** grid;
public:
	void Make();
	Board();
	void Check();
	void Delete();
	void Drop();
	void Swap(int x1, int y1, int x2, int y2);
	void setMenu(bool cond);
	bool getMenu();
	void setCond1(bool cond);
	bool getCond1();
	void setCond2(bool cond);
	bool getCond2();
	void setCond3(bool cond);
	bool getCond3();
	void setPause(bool cond);
	bool getPause();
	void setHighScoreMenu(bool highscoreMenu);
	bool getHighScoreMenu();
	void Display();
	void Hint();
	~Board();
};
#endif